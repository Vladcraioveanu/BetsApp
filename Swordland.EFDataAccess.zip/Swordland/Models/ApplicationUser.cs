﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Swordland.Models
{
    public class ApplicationUser : IdentityUser
    {
        //public string ImagePath { get; set; }

        //[PersonalData]
        //public string FullName { get; set; }
    }
}
